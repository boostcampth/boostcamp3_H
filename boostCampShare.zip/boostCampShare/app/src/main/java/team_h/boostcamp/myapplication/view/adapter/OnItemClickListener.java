package team_h.boostcamp.myapplication.view.adapter;

public interface OnItemClickListener {
    void onClickItem(int position);
}
