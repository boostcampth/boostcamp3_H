package team_h.boostcamp.myapplication.view;

<<<<<<< HEAD
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
=======
import android.content.pm.ActivityInfo;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
>>>>>>> 2b24997e93008a663f3ea562d934f41bed66263c

public abstract class BaseActivity<B extends ViewDataBinding> extends AppCompatActivity implements BaseView {

    protected B binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // bindingUtil 설정
        binding = DataBindingUtil.setContentView(this, getLayoutId());
    }

    protected abstract int getLayoutId();
}
