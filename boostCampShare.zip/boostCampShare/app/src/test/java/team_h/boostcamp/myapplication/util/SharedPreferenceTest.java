package team_h.boostcamp.myapplication.util;

import org.junit.Test;

public class SharedPreferenceTest {
    @Test
    public void setPreferencePassword() {

    }

    @Test
    public void getPreferencePassword() {
    }
}