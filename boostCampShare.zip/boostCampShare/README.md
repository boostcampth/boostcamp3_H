
# BOOST CAMP 3 Archive:rocket:

부스트캠프 3기(2019.01.21~2019.02.26) 안드로이드 H팀의 아카이브입니다. 4주간의 각종 기록을 모아놓은 공간입니다.  





## 팀원

* 이승우
* 이화중 [Github](http://github.com/huhsay)
* 원종성  





## 개발 문서

###  [Rules](https://github.com/huhsay/boostcamp3_archive/blob/master/rules.md)

- 캠프를 진행하면서 팀원끼리 지켜야할 규칙을 정의하였습니다.

### [Coding Convetion](https://github.com/huhsay/boostcamp3_archive/blob/master/codingConvention.md)

- 코딩작업시 지켜야할 코딩 컨벤션입니다.

### [Snippet](https://github.com/huhsay/boostcamp3_archive/blob/master/Snippet.md)

- 오늘 한 일, 내일 할 일에 대한 기록입니다.

### [Scrum](https://github.com/huhsay/boostcamp3_archive/blob/master/scrum.md)

- 아침 스크럼 기록입니다.

  



## 온라인저장소

- [구글드라이브](https://drive.google.com/open?id=1JS9bZnT89KKW8Z1ORy2EOlQM2xTkZMT9)

- [트렐로-칸반](https://trello.com/boostcamp3)

  



## 기획 문서

### [기능정의서](https://github.com/huhsay/boostcamp3_archive/blob/master/%EA%B2%B0%EA%B3%BC%EB%AC%BC/%EA%B8%B0%EB%8A%A5%EC%A0%95%EC%9D%98.md)

### 와이어프레임

* [미리보기](https://xd.adobe.com/view/d7fae8a9-172e-452c-5092-d06b594e1a8d-a1cb/)

* [전체화면](https://xd.adobe.com/spec/d34729d2-7312-4655-7430-36fbde0bfdc4-a576/)
